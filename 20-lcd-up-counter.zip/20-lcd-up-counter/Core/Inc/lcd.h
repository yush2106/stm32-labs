//define LCD pins
#define LCD_RS GPIO_PIN_9    //Register Select, 0 is command, 1 is data
#define LCD_EN GPIO_PIN_8    //LCD Enable
#define LCD_D4 GPIO_PIN_4    //LCD pin D4
#define LCD_D5 GPIO_PIN_5    //LCD pin D5
#define LCD_D6 GPIO_PIN_6    //LCD pin D6
#define LCD_D7 GPIO_PIN_7    //LCD pin D7
// #LCD_RW  //LCD Read=1, Write=0

//declare function
void LCD_Strobe();
void LCD_Write_Cmd(unsigned char c);
void LCD_Write_Data(unsigned char c);
void LCD_Clear();
void LCD_Puts(const char *s);
void LCD_PutCh(char c);
void LCD_GoTo_Position(int col, int row);
void LCD_initial();
